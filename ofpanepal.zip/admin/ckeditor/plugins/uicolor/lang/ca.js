﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ca",{title:"UI Color Picker",preview:"Vista prèvia",config:"Enganxa aquest text dins el fitxer config.js",predefined:"Conjunts de colors predefinits"});